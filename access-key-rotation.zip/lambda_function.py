import boto3
from botocore.exceptions import ClientError
import datetime
import json

# inicia el cliente de iam
iam_client = boto3.client('iam')

# lista de usuarios a excluir en la rotacion automatica
exclude_users=["fsalonia", "validators-app-prod"]

def lambda_handler(event, context):
    message = json.loads(event['Records'][0]['Sns']['Message'])
    resourceId = message["detail"]
    resourceId = resourceId["newEvaluationResult"]
    resourceId = resourceId["evaluationResultIdentifier"]
    resourceId = resourceId["evaluationResultQualifier"]
    resourceId = resourceId["resourceId"]
 
    listKeys(resourceId)
    getUserMail(resourceId)
    return message
    
def getUser(resourceId):
    response = iam_client.list_users()
    
    # entre todos los usuarios busca el que tenga userId igual al resourceid (valor que se trae desde el config)
    for user in response['Users']:
        if user['UserId'] == resourceId and user['UserName'] not in exclude_users: 
            return user['UserName']

# busca el mail del usuario en el tag mail
def getUserMail(resourceId):
    username = getUser(resourceId)
    
    tags = iam_client.list_user_tags(
        UserName=username,
    )
    
    for tag in tags['Tags']:
        if tag['Key'] == 'mail':
            mail = tag['Value']
            return mail
            
def listKeys(resourceId): 
    username = getUser(resourceId)
    keys = iam_client.list_access_keys(UserName=username)
    
    # si el usuario tiene mas de una access key borra la mas antigua y deshabilita la otra
    if len(keys['AccessKeyMetadata']) == 2:
        d1=keys['AccessKeyMetadata'][0]['CreateDate']
        d2=keys['AccessKeyMetadata'][1]['CreateDate']
        if d1 < d2:
            delete_key=keys['AccessKeyMetadata'][0]
            disable_key=keys['AccessKeyMetadata'][1]
        else:
            delete_key=keys['AccessKeyMetadata'][1]
            disable_key=keys['AccessKeyMetadata'][0]
        
        # desabilitar la key existe mas reciente
        disableKey(disable_key)
        # borrar key mas vieja
        deleteKey(delete_key)
        # create new key
        createKey(username)
        
    else:
        oldKey=keys['AccessKeyMetadata'][0] # en el caso q tenga una sola esta siempre va a ser la vieja
        # disable old key
        disableKey(oldKey)
        # create new key
        createKey(username)
    
def disableKey(key):
    ak = key['AccessKeyId']
    un = key['UserName']
    
    iam_client.update_access_key(
        AccessKeyId=ak,
        Status='Inactive',
        UserName=un
    )

def deleteKey(key):
    ak = key['AccessKeyId']
    un = key['UserName']
    
    iam_client.delete_access_key(
        AccessKeyId=ak,
        UserName=un
    )
    
def createKey(username):
    response = iam_client.create_access_key(
        UserName=username
    )
    print("New keys:")
    print(response)
